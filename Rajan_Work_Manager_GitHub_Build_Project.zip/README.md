# RAJAN WORK MANAGER

Android app for Personal and Dynamic Dance Academy work tracking.

## Features
- Personal and Academy task categories
- Add tasks with date/time reminders
- Mark tasks complete / undo / delete
- Completed and pending task counts
- Local task storage on the phone
- High-priority alarm-style reminder notifications

## Build APK on GitHub
1. Upload the contents of this project to your repository's `main` branch.
2. Open the repository's **Actions** tab.
3. Select **Build Android APK** and wait for the workflow to finish successfully.
4. Open the successful workflow run and download `rajan-work-manager-debug-apk` under Artifacts.
5. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

## Android permissions
Allow notifications and exact alarms for reminders. Alarm volume and sound are controlled partly by the phone's Android notification/alarm settings.

## Current MVP limitations
- Tasks are stored locally on the phone.
- Scheduled reminders are not restored after a phone reboot in this MVP.
- This is a debug APK build; it is not a Play Store signed release.
