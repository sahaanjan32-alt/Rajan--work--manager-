RAJAN WORK MANAGER - Android Studio project (starter version)

Is project me:
- Personal aur Academy tasks
- Task complete / undo / delete
- Completed aur pending count
- Task ke liye date/time reminder
- High-priority alarm notification with device alarm sound
- Tasks phone me locally save hote hain

APK banane ke liye:
1. Computer par Android Studio install karein.
2. Android Studio > Open > is ZIP ko extract karke RajanWorkManager folder select karein.
3. Gradle sync complete hone dein.
4. Android phone connect karein ya emulator use karein.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK app/build/outputs/apk/debug/app-debug.apk me milega.

Zaroori:
- Phone me app notifications allow karein.
- Android 12+ par Exact Alarm permission allow karein.
- Phone ki alarm/notification volume badhayein aur DND settings check karein.
- Ye starter project hai; is environment me compiled/signed APK nahi banaya gaya.
- Reboot ke baad scheduled alarms ko restore karne wala hissa abhi MVP me implement nahi hai.
