package com.rajan.workmanager;
import android.app.*;
import android.content.*;
import android.os.Build;
public class AlarmReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i){
  String task=i.getStringExtra("task"); if(task==null)task="Aapka kaam pending hai";
  Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,"rajan_alarm"):new Notification.Builder(c);
  b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("RAJAN WORK MANAGER")
   .setContentText(task).setStyle(new Notification.BigTextStyle().bigText(task))
   .setPriority(Notification.PRIORITY_MAX).setCategory(Notification.CATEGORY_ALARM)
   .setAutoCancel(true).setDefaults(Notification.DEFAULT_ALL);
  ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify((int)(System.currentTimeMillis()%100000),b.build());
 }
}
