package com.rajan.workmanager;
import android.content.*;
public class BootReceiver extends BroadcastReceiver {
 public void onReceive(Context c,Intent i) {
   // MVP note: alarms are scheduled again when app is reopened; persistent task list remains saved.
 }
}
