package com.rajan.workmanager;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, list;
    EditText taskInput;
    Spinner category;
    TextView counts;
    static final String PREF="tasks";
    ArrayList<String> tasks=new ArrayList<>();
    ArrayList<Boolean> done=new ArrayList<>();
    ArrayList<Long> times=new ArrayList<>();

    public void onCreate(Bundle b) {
        super.onCreate(b);
        createChannel();
        askPermissions();
        load();
        buildUi();
    }
    void askPermissions(){
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10);
    }
    void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel ch=new NotificationChannel("rajan_alarm","Work reminders",NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("Loud reminders for pending work");
            ch.enableVibration(true);
            ch.setSound(android.provider.Settings.System.DEFAULT_ALARM_ALERT_URI,
                new android.media.AudioAttributes.Builder().setUsage(android.media.AudioAttributes.USAGE_ALARM).build());
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    int dp(int v){return (int)(v*getResources().getDisplayMetrics().density);}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(dp(8),dp(8),dp(8),dp(8));return t;}
    void buildUi(){
        root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(16),dp(18),dp(16),dp(10));root.setBackgroundColor(Color.rgb(18,18,18));
        ScrollView scroll=new ScrollView(this); LinearLayout page=new LinearLayout(this);page.setOrientation(1);
        TextView title=text("RAJAN WORK MANAGER",23,0xFFFFD36A);title.setGravity(Gravity.CENTER);page.addView(title);
        TextView sub=text("PERSONAL  •  DYNAMIC DANCE ACADEMY",12,Color.LTGRAY);sub.setGravity(Gravity.CENTER);page.addView(sub);
        counts=text("",15,Color.WHITE);counts.setGravity(Gravity.CENTER);page.addView(counts);
        taskInput=new EditText(this);taskInput.setSingleLine(true);taskInput.setHint("Naya kaam likhiye...");taskInput.setTextColor(Color.WHITE);taskInput.setHintTextColor(0xFFAAAAAA);page.addView(taskInput);
        category=new Spinner(this);String[] cats={"Personal","Academy"};category.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,cats));page.addView(category);
        Button add=button("＋  ADD TASK");page.addView(add);add.setOnClickListener(v->addTask());
        Button alarm=button("ALARM / EXACT REMINDER SETTINGS");page.addView(alarm);alarm.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=31 && !getSystemService(AlarmManager.class).canScheduleExactAlarms()) startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM));});
        TextView note=text("Pending tasks ke reminder ke liye task add karte waqt date/time set karein. Alarm ke liye app notifications aur exact alarm permission allow karein.",12,0xFFCCCCCC);page.addView(note);
        list=new LinearLayout(this);list.setOrientation(1);page.addView(list);
        scroll.addView(page);root.addView(scroll);setContentView(root);render();
    }
    Button button(String s){Button b=new Button(this);b.setText(s);b.setTextColor(0xFF171717);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFFFFD36A));return b;}
    void addTask(){
        String s=taskInput.getText().toString().trim();if(s.isEmpty()){taskInput.setError("Kaam likhiye");return;}
        tasks.add((String)category.getSelectedItem()+" | "+s);done.add(false);times.add(0L);save();taskInput.setText("");render();
        int i=tasks.size()-1;
        Calendar c=Calendar.getInstance();c.add(Calendar.HOUR,1);
        new TimePickerDialog(this,(view,h,m)->new DatePickerDialog(this,(dv,y,mo,d)->{
            Calendar when=Calendar.getInstance();when.set(y,mo,d,h,m,0);when.set(Calendar.MILLISECOND,0);
            if(when.getTimeInMillis()<=System.currentTimeMillis()){Toast.makeText(this,"Future time select karein",Toast.LENGTH_LONG).show();return;}
            times.set(i,when.getTimeInMillis());save();schedule(i);render();
            Toast.makeText(this,"Reminder set: "+new SimpleDateFormat("dd MMM, hh:mm a",Locale.getDefault()).format(when.getTime()),Toast.LENGTH_LONG).show();
        },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show(),c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),false).show();
    }
    void schedule(int i){
        if(times.get(i)==0 || done.get(i))return;
        Intent in=new Intent(this,AlarmReceiver.class);in.putExtra("task",tasks.get(i));
        PendingIntent pi=PendingIntent.getBroadcast(this,i,in,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);
        if(Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()){Toast.makeText(this,"Exact alarm permission allow karein",Toast.LENGTH_LONG).show();return;}
        if(Build.VERSION.SDK_INT>=23)am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,times.get(i),pi);else am.setExact(AlarmManager.RTC_WAKEUP,times.get(i),pi);
    }
    void render(){
        if(list==null)return;list.removeAllViews();int completed=0;for(boolean d:done)if(d)completed++;
        counts.setText("COMPLETED: "+completed+"     PENDING: "+(tasks.size()-completed));
        for(int i=0;i<tasks.size();i++){
            final int ix=i;LinearLayout row=new LinearLayout(this);row.setOrientation(0);row.setGravity(Gravity.CENTER_VERTICAL);
            TextView label=text((done.get(i)?"✓  ":"○  ")+tasks.get(i),15,done.get(i)?0xFF8BCF9B:Color.WHITE);label.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));row.addView(label);
            Button toggle=new Button(this);toggle.setText(done.get(i)?"Undo":"Done");row.addView(toggle);
            toggle.setOnClickListener(v->{done.set(ix,!done.get(ix));save();render();});
            Button del=new Button(this);del.setText("×");row.addView(del);del.setOnClickListener(v->{tasks.remove(ix);done.remove(ix);times.remove(ix);save();render();});
            if(times.get(i)>0)label.append("\n"+new SimpleDateFormat("dd MMM yyyy, hh:mm a",Locale.getDefault()).format(new Date(times.get(i))));
            list.addView(row);View line=new View(this);line.setBackgroundColor(0xFF444444);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(1));list.addView(line,lp);
        }
    }
    void save(){StringBuilder a=new StringBuilder(),b=new StringBuilder(),c=new StringBuilder();for(int i=0;i<tasks.size();i++){if(i>0){a.append("§");b.append("§");c.append("§");}a.append(tasks.get(i).replace("§"," "));b.append(done.get(i)?"1":"0");c.append(times.get(i));}getSharedPreferences(PREF,0).edit().putString("t",a.toString()).putString("d",b.toString()).putString("tm",c.toString()).apply();}
    void load(){String a=getSharedPreferences(PREF,0).getString("t",""),b=getSharedPreferences(PREF,0).getString("d",""),c=getSharedPreferences(PREF,0).getString("tm","");if(!a.isEmpty()){String[] x=a.split("§",-1),y=b.split("§",-1),z=c.split("§",-1);for(int i=0;i<x.length;i++){tasks.add(x[i]);done.add(i<y.length&&y[i].equals("1"));times.add(i<z.length?Long.parseLong(z[i]):0L);}}}
}
